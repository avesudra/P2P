#ifndef IPLIST_H
#define IPLIST_H
#include <QStringList>
#include <QFile>
#include <stdarg.h>
#include <QTextStream>
#include <QDebug>
class IPList
{
public:
    IPList(QString path);
    IPList();
    ~IPList();
    void writeips(QStringList ips);
    QStringList readip();
private:
    QString pathtolistfile;
    QFile listfile;
};

#endif // IPLIST_H
