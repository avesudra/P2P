#include "iplist.h"

IPList::IPList(QString path)
{

    pathtolistfile=path;
    listfile.setFileName(pathtolistfile);

}
IPList::IPList()
{
    listfile.setFileName("iplist.ips");

}

IPList::~IPList()
{
    //listfile.~QFile();
}

void IPList::writeips(QStringList ips)
{
    listfile.open(QIODevice::WriteOnly | QIODevice::Append);
    QTextStream s(&listfile);
    for(int i = ips.length()-1; i!=-1;--i)
    s<<ips.at(i).toAscii()<<endl;
    listfile.close();
}
QStringList IPList::readip()
{
    listfile.open(QIODevice::ReadOnly );
    QStringList temp;
    while(listfile.atEnd())
    {
        temp<<listfile.readLine();
    }
    listfile.close();
    return temp;

}
