var searchData=
[
  ['writeinfo',['writeinfo',['../class_data.html#a70badcb84e6150b0fd11980cf2c53ef9',1,'Data']]]
];
