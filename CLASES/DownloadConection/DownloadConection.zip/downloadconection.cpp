#include "downloadconection.h"

DownloadConection::DownloadConection()
{
}
