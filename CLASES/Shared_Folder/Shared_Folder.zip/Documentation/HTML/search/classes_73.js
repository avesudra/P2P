var searchData=
[
  ['shared_5ffolder',['Shared_Folder',['../class_shared___folder.html',1,'']]]
];
