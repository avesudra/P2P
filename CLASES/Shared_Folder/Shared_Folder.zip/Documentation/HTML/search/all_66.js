var searchData=
[
  ['files',['files',['../class_shared___folder.html#a219ccfb35afbaeae876acd6028cbb24f',1,'Shared_Folder']]]
];
