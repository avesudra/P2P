var searchData=
[
  ['update_5fstatistics',['update_statistics',['../class_shared___folder.html#a08ea799266cd42f5725ce606ed489409',1,'Shared_Folder']]]
];
